/*Row class. just a vector of Strings*/

#pragma once
#include<vector>
#include"String.h"
class Row: public vector<string>
{
};

