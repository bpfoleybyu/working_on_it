/* the Header class is just a vector of Strings*/

#pragma once
#include"String.h"
#include<vector>

class Header: public vector<string>
{
};

